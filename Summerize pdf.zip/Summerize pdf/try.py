from flask import Flask, request, render_template, redirect, url_for
from PyPDF2 import PdfReader
import tempfile
import os

app = Flask(__name__)

# Dictionary to store uploaded PDFs
uploaded_pdfs = {}

@app.route('/upload', methods=['GET', 'POST'])
def upload_pdf():
    if request.method == 'POST':
        uploaded_file = request.files['file']

        if uploaded_file.filename == '':
            return render_template('try.html', result="No file selected!")

        if uploaded_file and uploaded_file.filename.endswith('.pdf'):
            with tempfile.NamedTemporaryFile(delete=False) as temp_file:
                uploaded_file.save(temp_file.name)
                pdfreader = PdfReader(temp_file.name)

            file_id = str(len(uploaded_pdfs))
            uploaded_pdfs[file_id] = pdfreader

            return redirect(url_for('query_pdf', file_id=file_id))

    return render_template('try.html', result=None)


@app.route('/query/<file_id>', methods=['GET', 'POST'])
def query_pdf(file_id):
    if request.method == 'POST':
        query = request.form['query']
        pdfreader = uploaded_pdfs.get(file_id)

        if not pdfreader:
            return render_template('q.html', result="File not found!")

        # Read PDF file and extract text (example code; adapt as needed)
        raw_text = ''
        for i, page in enumerate(pdfreader.pages):
            content = page.extract_text()
            if content:
                raw_text += content

        result = "Result for your query." # Replace with actual processing code

        return render_template('q.html', result=result, file_id=file_id)

    return render_template('q.html', result=None, file_id=file_id)

if __name__ == '__main__':
    app.run(debug=True)
